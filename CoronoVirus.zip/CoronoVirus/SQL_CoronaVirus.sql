--select TOP 100 * from coronavirus
-- To avoid any errors, check missing value / null value 
-- Q1. Write a code to check NULL values
select * from coronavirus where province is null 

--Q2. If NULL values are present, update them with zeros for all columns. 
update coronavirus 
set province=coalesce(province,0),
CountryorRegion=coalesce(CountryorRegion,0),
Latitude=coalesce(Latitude,0),
Longitude=coalesce(Longitude,0),
Date=coalesce(Date,0),
Confirmed=coalesce(Confirmed,0),
Deaths=coalesce(Deaths,0),
Recovered=coalesce(Recovered,0)
where province is null or CountryorRegion is null or Latitude is null or Longitude is null or
Date is null or Confirmed is null or Deaths is null or Recovered is null

-- Q3. check total number of rows
select count(*) as totalrows from coronavirus

-- Q4. Check what is start_date and end_date
select min(date)start_date,max(date)  end_date from coronavirus

-- Q5. Number of month present in dataset
select count(distinct format(date,'%y-%M') ) num_months from coronavirus

-- Q6. Find monthly average for confirmed, deaths, recovered
select month(date) months,avg(confirmed)confirmed,avg(deaths)deaths,avg(recovered)recovered from coronavirus
group by month(date)

-- Q7. Find most frequent value for confirmed, deaths, recovered each month 
SELECT * FROM (select month(date) months,confirmed,deaths,recovered,
ROW_NUMBER() OVER (PARTITION BY month(date) 
ORDER BY COUNT(*) DESC) AS rn
	from coronavirus  group by month(date),confirmed,deaths,recovered
	)A WHERE RN=1

-- Q8. Find minimum values for confirmed, deaths, recovered per year
select year(date) years,min(confirmed)minconfirmed,min(deaths)mindeaths,min(recovered)minrecovered
from coronavirus group by year(date) order by year(date)

-- Q9. Find maximum values of confirmed, deaths, recovered per year
select year(date) years,max(confirmed)maxconfirmed,max(deaths)maxdeaths,max(recovered)maxrecovered
from coronavirus group by year(date) order by year(date)

-- Q10. The total number of case of confirmed, deaths, recovered each month
select month(date) mnt_count,year(date) years,sum(confirmed)totalconfirmed,sum(deaths)totaldeaths,
sum(recovered)totalrecovered from coronavirus group by month(date),year(date) 

-- Q11. Check how corona virus spread out with respect to confirmed case
--      (Eg.: total confirmed cases, their average, variance & STDEV )
select sum(confirmed) total_confirmed_cases,avg(Confirmed)average_confirmed_cases,STDEV(confirmed)variance_confirmed_cases,var(confirmed)variance_confirmed_cases 
from coronavirus

-- Q12. Check how corona virus spread out with respect to death case per month
--      (Eg.: total confirmed cases, their average, variance & STDEV )
select month(date) months,sum(confirmed) total_confirmed_cases,avg(Confirmed)average_confirmed_cases,
STDEV(confirmed)variance_confirmed_cases,var(confirmed)variance_confirmed_cases ,
sum(deaths) total_death_cases,avg(deaths)average_death_cases,
STDEV(deaths)variance_deaths_cases,var(deaths)variance_death_cases 
from coronavirus group by month(date)

-- Q13. Check how corona virus spread out with respect to recovered case
--      (Eg.: total confirmed cases, their average, variance & STDEV )
select month(date) months,sum(confirmed) total_confirmed_cases,avg(Confirmed)average_confirmed_cases,
STDEV(confirmed)variance_confirmed_cases,var(confirmed)variance_confirmed_cases ,
sum(recovered) total_recovered_cases,avg(deaths)average_recovered_cases,
STDEV(recovered)variance_recovered_cases,var(recovered)variance_recovered_cases 
from coronavirus group by month(date)

-- Q14. Find Country having highest number of the Confirmed case
select top 1 countryorregion,max(confirmed)'highest number of the Confirmed case' from coronavirus 
group by countryorregion
order by 'highest number of the Confirmed case' desc

-- Q15. Find Country having lowest number of the death case
select top 1 countryorregion,min(deaths)'lowest number of the death case'  from coronavirus
group by countryorregion order by 'lowest number of the death case' asc

-- Q16. Find top 5 countries having highest recovered case
select top 5 countryorregion,max(recovered)'highest recovered case'
from coronavirus group by countryorregion order by 'highest recovered case' desc